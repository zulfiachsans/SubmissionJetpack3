package com.dicoding.submissionjetpack3.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}