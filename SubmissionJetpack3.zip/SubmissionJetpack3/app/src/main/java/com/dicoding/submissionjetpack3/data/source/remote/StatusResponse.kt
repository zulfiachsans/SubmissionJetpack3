package com.dicoding.submissionjetpack3.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}